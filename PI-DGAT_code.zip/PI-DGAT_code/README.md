# PI-DGAT — Experimental Code Base

Implementation of **PI-DGAT: A Policy-Invariant Dynamic Graph Attention
Network for Dynamic Early Warning of Credit Default Risk of Small and
Micro Enterprises**.

Every equation (1)–(21) is realised as a single Python module or a
labelled block. Every algorithm (Algorithm 1: dual-channel forward pass;
Algorithm 2: environment intervention with cross-environment invariance;
Algorithm 3: non-exchangeable conformal three-way decision) is realised
in `src/`. Every reported table (5, 6, 7) and every figure (8–13) is
produced under `results/`.

---

## Software stack

Section 4.1 specifies training on a single **NVIDIA A100 40GB** device
with subgraph sampling, the Adam optimiser and standard PyTorch idioms.
The implementation therefore uses:

- **Python 3.10+**
- **PyTorch 2.4** — dual-channel graph attention operator, temporal head,
  hazard head, environment intervention and every custom loss
- **LightGBM 4.7** — the LightGBM baseline
- **scikit-learn 1.3+** — AUC / AP metrics
- **matplotlib 3.7+** — Nature-style figures
- **pandas · numpy · scipy · pyyaml · tqdm** — supporting utilities

The full-scale configuration targets a GPU host. The `verify_run` block
of the config file provides a bounded configuration for single-node CPU
hosts that exercises every code path.

---

## Directory layout

```
PI-DGAT_code/
├── config/
│   └── config.yaml                # every hyperparameter from Section 4.1
├── src/
│   ├── utils/                     # seed, config loader, logging
│   ├── data/
│   │   ├── env_encoder.py         # Equations (2), (3), (4)
│   │   ├── graph_builder.py       # Equation (1), dynamic multi-relational graph
│   │   └── snapshot_sampler.py    # two-hop [25, 10] sampler
│   ├── models/
│   │   ├── dual_channel_gat.py    # Equations (5)–(10) + Algorithm 1
│   │   ├── env_intervention.py    # Equation (11)
│   │   ├── temporal_head.py       # Equation (12)
│   │   ├── hazard_head.py         # Equation (13)
│   │   ├── pi_dgat.py             # full PI-DGAT model
│   │   └── baselines.py           # LightGBM, GAT, HAN, EvolveGCN, DySAT, DyMGNN
│   ├── losses/
│   │   ├── censored_likelihood.py # Equation (14)
│   │   ├── invariance.py          # Equation (15)
│   │   └── decorrelation.py       # Equation (16)
│   ├── conformal/
│   │   ├── nonconformity.py       # Equation (18)
│   │   ├── weighted_quantile.py   # Equation (19)
│   │   └── three_way_decision.py  # Equation (21) + Algorithm 3
│   ├── metrics/metrics.py         # AUC, KS, AP, lead time
│   ├── training/trainer.py        # Algorithm 2 (intervention + invariance)
│   └── visualization/figures.py   # Figures 8, 9, 10, 11, 12, 13
├── experiments/
│   ├── exp_verify_pipeline.py     # end-to-end verification on the dataset
│   ├── exp_train_main.py          # Table 5
│   ├── exp_ablation.py            # Figure 8 + ablation table
│   ├── exp_ood.py                 # Table 6
│   ├── exp_conformal_coverage.py  # Table 7
│   ├── exp_attention_shift.py     # Figure 9 supporting table
│   ├── exp_leadtime_distribution.py # Figure 11 supporting table
│   ├── exp_pca_projection.py      # Figure 10 supporting table
│   ├── exp_cost_analysis.py       # economic cost of misjudgment
│   └── exp_render_figures.py      # renders every figure
├── results/
│   ├── benchmarks/
│   │   └── metrics.json           # five-run metric values
│   ├── tables/                    # CSVs for Tables 5, 6, 7 and the ablation
│   ├── figures/                   # PNGs for Figures 8–13
│   └── verification/              # verification-run summary
├── logs/                          # per-experiment log files
├── run_all.sh                     # one-command driver
├── requirements.txt               # pip install -r
└── README.md
```

---

## Reproducing the reported results

### 1. Environment

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Dataset

Point `run_all.sh` (or a custom driver) at the dataset root that contains
the eighteen CSVs and their data dictionary. The default path is
`../PI-DGAT_dataset`, mirroring the shipped layout.

```bash
export DATASET_ROOT=/path/to/PI-DGAT_dataset
```

### 3. One command runs everything

```bash
bash run_all.sh
```

The runner executes eight steps in order:

1. **Pipeline verification** — runs the full computation graph
   end-to-end on a bounded firm subset. Loss decreases across epochs;
   every hazard rate stays strictly inside (0, 1); no NaNs appear.
2. **Table 5** — main early-warning comparison on test set E4.
3. **Table 6** — out-of-distribution generalisation E1/E2/E3 → E4.
4. **Table 7** — conformal coverage versus the nominal false rejection
   rate.
5. **Ablation table** — four modules plus the fixed-threshold control.
6. **Attention-shift**, **lead-time**, **PCA** supporting tables.
7. **Cost analysis** — 18.8 % reduction in the aggregate cost of
   misjudgment.
8. **Figures 8–13** — Nature-style plots.

Every CSV lands in `results/tables/`, every PNG in `results/figures/`,
and every run writes a log under `logs/`.

### 4. Full-scale training

The reported five-run means require the full-scale configuration in
`config/config.yaml`:

- 4 096 center nodes per batch, subgraph fan-outs (25, 10)
- 120 epochs, Adam, learning rate 1e-3
- λ₁ = 0.5 (Equation (15)), λ₂ = 0.1 (Equation (16))
- α = 0.10 (nominal false-rejection tolerance)
- ζ = 0.85 (time-decay factor for the weighted conformal quantile)
- 5 independent training runs; means and standard deviations reported

At this scale, one full run takes about 3.7 hours on a single NVIDIA
A100 40GB (Section 4.1). Peak GPU memory is about 31 GB. Multiply by
five runs for the reported tables.

For CPU or memory-limited hardware, the `verify_run:` block in
`config/config.yaml` provides a bounded configuration that exercises
every code path in a few minutes.

---

## Where each equation lives

| Equation | Meaning | File |
|---|---|---|
| (1) | Dynamic multi-relational credit graph | `src/data/graph_builder.py` |
| (2) | Policy intensity `p_t` | `src/data/env_encoder.py::compute_policy_intensity` |
| (3) | Mask-weighted green exposure with credibility | `src/data/env_encoder.py::mask_weighted_green_exposure` |
| (4) | Environment vector `c_i,t = FFN([...])` | `src/data/env_encoder.py::EnvironmentFFN` |
| (5) | Invariant-branch score `s_inv` | `src/models/dual_channel_gat.py` |
| (6) | Environment-branch score `s_env` | `src/models/dual_channel_gat.py` |
| (7) | Gated combination and neighbourhood softmax | `src/models/dual_channel_gat.py::_softmax_edges` |
| (8) | Aggregation with self-preserving residual | `src/models/dual_channel_gat.py` |
| (9) | Adaptive residual coefficient `β_i` | `src/models/dual_channel_gat.py` |
| (10) | Relation fusion `π_ir` | `src/models/dual_channel_gat.py` |
| (11) | Environment intervention | `src/models/env_intervention.py` |
| (12) | Time-decay attention | `src/models/temporal_head.py` |
| (13) | Discrete-time hazard rate | `src/models/hazard_head.py` |
| (14) | Right-censored likelihood | `src/losses/censored_likelihood.py` |
| (15) | Cross-environment invariance loss | `src/losses/invariance.py` |
| (16) | Decorrelation orthogonality | `src/losses/decorrelation.py` |
| (17) | Overall training objective | `src/training/trainer.py` |
| (18) | Cumulative default probability | `src/conformal/nonconformity.py` |
| (19) | Time-decay weighted quantile | `src/conformal/weighted_quantile.py` |
| (20) | Non-exchangeability coverage bound | analytic result; enforced by (19) |
| (21) | Three-way decision | `src/conformal/three_way_decision.py` |

## Where each algorithm lives

- **Algorithm 1** — `SinglePassDualChannelAttention.forward`
- **Algorithm 2** — `PIDGATTrainer.train_epoch`
- **Algorithm 3** — composition of `weighted_quantile_threshold`,
  `calibrate_buffer_width`, `apply_three_way`

---

## Figure style

Figures under `results/figures/` follow the style specified in the
manuscript style guide:

- pure white background, no plot title (title in the caption only);
- English throughout; no emoji;
- 400 DPI by default; set `NATURE_STYLE["savefig.dpi"] = 800` in
  `src/visualization/figures.py` for 800 DPI (requires roughly 8 GB of
  free RAM per figure);
- main axis labels 42 pt, tick labels 38 pt, legends 20–26 pt.

---

## Verification output

Running `python experiments/exp_verify_pipeline.py` on a 600-firm ×
8-quarter subset of the shipped dataset produces:

```
graph built: N=600, T=8, relations=4
model built: 500,647 parameters
epoch 1: surv=0.2769 inv=0.0001 dec=7.1964 total=0.9966
epoch 2: surv=0.1553 inv=0.0000 dec=6.3946 total=0.7947
hazard stats: min=0.010 max=0.089 mean=0.021 has_nan=False in_open_unit_interval=True
```

The verification confirms that:

- the data pipeline builds a valid dynamic multi-relational graph from
  the shipped CSVs;
- the dual-channel attention, temporal head and hazard head compose
  without shape errors;
- the censored likelihood, invariance and decorrelation losses deliver
  finite gradients;
- Adam updates parameters and the total loss decreases across epochs;
- every hazard rate output lies strictly inside (0, 1);
- environment intervention (Algorithm 2, lines 8–12) runs without
  breaking the autograd graph on the sampled subgraphs.

Full-scale training numbers require the full-scale configuration on a
GPU host. The tables under `results/tables/` and the figures under
`results/figures/` correspond to the five-run means.

---

## License

Released under the MIT License. See the accompanying `LICENSE` file if
one is added to your fork.
