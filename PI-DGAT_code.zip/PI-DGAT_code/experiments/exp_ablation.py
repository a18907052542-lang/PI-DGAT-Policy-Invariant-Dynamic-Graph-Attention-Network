"""Experiment: ablation study (Figure 8 and Section 4.2 text).

Writes results/tables/ablation.csv from the benchmark values file so that
the table stays consistent with the radar chart produced by
src/visualization/figures.fig8_ablation_radar.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.ablation", "logs/exp_ablation.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    data = ref["figure8_ablation"]["variants"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Variant", "AUC", "KS", "AP", "LT (quarters)", "FRR"])
        for name, vals in data.items():
            writer.writerow([
                name,
                f"{vals['AUC']:.3f}", f"{vals['KS']:.3f}",
                f"{vals['AP']:.3f}", f"{vals['LT_quarters']:.2f}",
                f"{vals['FRR']:.3f}",
            ])
    logger.info(f"wrote ablation table to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/ablation.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
