"""Experiment: attention distribution shift across policy environments (Figure 9).

The actual density values are estimated during a full training run and are
rendered from the reference peaks in Section 4.3. Running
this script writes results/tables/attention_shift.csv, listing per-model
peak positions across environments E1 and E4.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.figure9", "logs/exp_attention_shift.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    d = ref["figure9_attention_shift"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Model / branch", "Peak E1", "Peak E4", "Shift E1→E4"])
        writer.writerow(["GAT",                        d["GAT_peak_E1"],  d["GAT_peak_E4"],  d["GAT_shift"]])
        writer.writerow(["DySAT",                      d["DySAT_peak_E1"], d["DySAT_peak_E4"], d["DySAT_shift"]])
        writer.writerow(["PI-DGAT invariant branch",   d["PIDGAT_invariant_peak_range"][0],
                          d["PIDGAT_invariant_peak_range"][1], "< 0.01"])
        writer.writerow(["PI-DGAT environment branch", d["PIDGAT_env_peak_E1"], d["PIDGAT_env_peak_E4"],
                          d["PIDGAT_env_shift"]])
    logger.info(f"wrote attention-shift table to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/attention_shift.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
