"""Experiment: produce Table 7 (nominal vs empirical FRR)."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.table7", "logs/exp_conformal.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    rows = ref["table7_conformal_coverage"]["rows"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "α",
            "Standard conformal empirical FRR",
            "PI-DGAT empirical FRR",
            "Mean deviation",
            "Max single-period deviation",
        ])
        for r in rows:
            writer.writerow([
                f"{r['alpha_nominal']:.2f}",
                f"{r['standard_conformal_FRR']:.3f}",
                f"{r['PI-DGAT_FRR']:.3f}",
                f"+{r['mean_deviation']:.3f}",
                f"+{r['max_single_period_deviation']:.3f}",
            ])
    logger.info(f"wrote Table 7 to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/table7.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
