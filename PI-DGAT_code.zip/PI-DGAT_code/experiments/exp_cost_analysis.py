"""Experiment: economic cost of misjudgment (Section 4.4 last paragraph).

Uses the caliber stated in Section 4.4:
- annualised net interest margin on inclusive SME loans: 3.2%
- non-performing loan recovery rate: 35%
- unit loss of a missed default: 65% of the exposure
- unit loss of a false rejection: one year of net interest margin income

At operating points:
- PI-DGAT       recall 0.685, FRR 0.108
- strongest baseline recall 0.656, FRR 0.141

Reported result: total cost of misjudgment under PI-DGAT is 18.8% lower
than under the strongest baseline (2.5pp from lower missed defaults, 16.3pp
from opportunity-cost savings from FRR control).
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def cost_per_100_loans(recall: float, frr: float,
                        exposure_per_loan: float,
                        base_rate: float,
                        loss_missed_default_pct_expo: float,
                        annual_nim_pct: float) -> tuple[float, float, float]:
    """Return (missed_default_cost, opportunity_cost, total_cost) per 100 loans.

    The two error categories cannot both be zero because base_rate > 0.
    """
    n_default = 100 * base_rate
    n_non_default = 100 * (1 - base_rate)
    missed = (1 - recall) * n_default
    false_rej = frr * n_non_default
    md_cost = missed * exposure_per_loan * loss_missed_default_pct_expo
    op_cost = false_rej * exposure_per_loan * annual_nim_pct
    return md_cost, op_cost, md_cost + op_cost


def main(benchmarks_path: str, out_path: str,
          exposure_per_loan: float = 500_000.0,
          base_rate: float = 0.0088):
    logger = get_logger("exp.cost", "logs/exp_cost.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    ca = ref["cost_analysis"]
    ann = ca["annualised_net_interest_margin_inclusive_SME_pct"] / 100.0
    ldef = ca["unit_loss_missed_default_pct_of_exposure"] / 100.0

    md_p, op_p, tot_p = cost_per_100_loans(
        ca["PI-DGAT_recall_at_operating_point"],
        ca["PI-DGAT_FRR_at_operating_point"],
        exposure_per_loan, base_rate, ldef, ann,
    )
    md_b, op_b, tot_b = cost_per_100_loans(
        ca["strongest_baseline_recall_at_operating_point"],
        ca["strongest_baseline_FRR_at_operating_point"],
        exposure_per_loan, base_rate, ldef, ann,
    )
    saving_pct = (tot_b - tot_p) / tot_b * 100
    md_saving_pp = (md_b - md_p) / tot_b * 100
    op_saving_pp = (op_b - op_p) / tot_b * 100

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Configuration", "Operating recall", "Operating FRR",
                          "Missed-default cost (RMB per 100 loans)",
                          "Opportunity cost (RMB per 100 loans)",
                          "Total cost (RMB per 100 loans)"])
        writer.writerow(["PI-DGAT",
                          f"{ca['PI-DGAT_recall_at_operating_point']:.3f}",
                          f"{ca['PI-DGAT_FRR_at_operating_point']:.3f}",
                          f"{md_p:,.0f}", f"{op_p:,.0f}", f"{tot_p:,.0f}"])
        writer.writerow(["Strongest baseline",
                          f"{ca['strongest_baseline_recall_at_operating_point']:.3f}",
                          f"{ca['strongest_baseline_FRR_at_operating_point']:.3f}",
                          f"{md_b:,.0f}", f"{op_b:,.0f}", f"{tot_b:,.0f}"])
        writer.writerow([])
        writer.writerow(["Model saving \u2014 aggregate (%)", "", "",
                          f"{ca['reduction_from_lower_missed_defaults_pp']:.1f} pp",
                          f"{ca['reduction_from_opportunity_cost_savings_pp']:.1f} pp",
                          f"{ca['total_misjudgment_cost_reduction_vs_strongest_baseline_pct']:.1f} %"])
        writer.writerow(["Model saving reconstructed here (%)", "", "",
                          f"{md_saving_pp:.1f} pp",
                          f"{op_saving_pp:.1f} pp",
                          f"{saving_pct:.1f} %"])
    logger.info(f"wrote cost analysis to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/cost_analysis.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
