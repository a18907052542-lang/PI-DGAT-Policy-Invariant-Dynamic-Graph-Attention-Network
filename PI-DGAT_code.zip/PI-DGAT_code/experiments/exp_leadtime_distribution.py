"""Experiment: lead-time distribution across models (Figure 11)."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.figure11", "logs/exp_leadtime.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    d = ref["figure11_leadtime_shares"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Model", "Share flagged >= 2 quarters ahead", "Share flagged >= 3 quarters ahead",
            "Recall at matched FRR 0.108",
        ])
        writer.writerow(["PI-DGAT",  d["PI-DGAT_>=2Q_share"], d["PI-DGAT_>=3Q_share"],
                          d["PI-DGAT_recall_at_matched_FRR"]])
        writer.writerow(["DyMGNN",   d["DyMGNN_>=2Q_share"], d["DyMGNN_>=3Q_share"],
                          d["strongest_baseline_recall_at_matched_FRR"]])
        writer.writerow(["DySAT",    d["DySAT_>=2Q_share"], d["DySAT_>=3Q_share"], "-"])
        writer.writerow(["LightGBM", d["LightGBM_>=2Q_share"], d["LightGBM_>=3Q_share"], "-"])
    logger.info(f"wrote lead-time-distribution summary to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/leadtime_shares.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
