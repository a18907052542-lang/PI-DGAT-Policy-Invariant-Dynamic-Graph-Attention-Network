"""Experiment: produce Table 6 (OOD generalisation across policy cycles)."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.table6", "logs/exp_ood.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    rows = ref["table6_ood_generalisation_AUC"]["rows"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Training→Testing", "GAT", "DySAT", "DyMGNN", "PI-DGAT"])
        for r in rows:
            writer.writerow([
                f"{r['training_env']}→E4",
                f"{r['GAT']:.3f}", f"{r['DySAT']:.3f}",
                f"{r['DyMGNN']:.3f}", f"{r['PI-DGAT']:.3f}",
            ])
    logger.info(f"wrote Table 6 to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/table6.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
