"""Render every figure (8 through 13) into results/figures/."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from src.utils.logging_utils import get_logger
from src.visualization.figures import render_all


def main(out_dir: str):
    logger = get_logger("figures", "logs/render_figures.log")
    out = Path(out_dir)
    render_all(out)
    for f in sorted(out.glob("*.png")):
        logger.info(f"rendered {f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="results/figures")
    args = parser.parse_args()
    main(args.out_dir)
