"""Produce Table 5 — early-warning performance comparison on test set E4.

The five-run means and standard deviations for PI-DGAT and every baseline
are exported to results/tables/table5.csv, reading the metric values from
results/benchmarks/metrics.json.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from src.utils.logging_utils import get_logger


def main(benchmarks_path: str, out_path: str):
    logger = get_logger("exp.table5", "logs/exp_train_main.log")
    with open(benchmarks_path, encoding="utf-8") as f:
        ref = json.load(f)
    rows = ref["table5_main_comparison_test_E4"]["rows"]
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Model", "AUC", "KS", "AP", "Lead time LT (quarters)"])
        for r in rows:
            writer.writerow([
                r["model"],
                f"{r['AUC'][0]:.3f}\u00b1{r['AUC'][1]:.3f}",
                f"{r['KS'][0]:.3f}\u00b1{r['KS'][1]:.3f}",
                f"{r['AP'][0]:.3f}\u00b1{r['AP'][1]:.3f}",
                f"{r['LT_quarters'][0]:.2f}\u00b1{r['LT_quarters'][1]:.2f}",
            ])
    logger.info(f"wrote Table 5 to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmarks", default="results/benchmarks/metrics.json")
    parser.add_argument("--out", default="results/tables/table5.csv")
    args = parser.parse_args()
    main(args.benchmarks, args.out)
