"""Pipeline verification: run the full PI-DGAT computation graph end-to-end.

The script exercises every module — data pipeline, dual-channel attention,
temporal head, hazard head, censored likelihood, invariance term,
decorrelation term, environment intervention and the conformal decision
layer — on a bounded firm subset drawn from the shipped dataset. It reports
loss trajectory and hazard-rate distribution so that any regression in the
forward or backward pass is caught quickly.

The default subset size, batch size and epoch count are read from the
``verify_run`` block of ``config/config.yaml`` and are set for a single-node
CPU environment. Full-scale training uses the top-level ``train`` block on a
GPU host.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from src.data.graph_builder import build_dynamic_graph
from src.models.pi_dgat import PIDGAT
from src.training.trainer import PIDGATTrainer, Sample
from src.utils.logging_utils import get_logger
from src.utils.seed import load_config, set_global_seed


def sample_training_records(graph, quarters, env_of_q, rng, n_target=800,
                              default_rate=0.02):
    """Draw (firm, quarter, default_label) tuples over the current window.

    Firms are drawn uniformly at random from the surviving nodes; observation
    quarters are placed in the mid-life segment of each firm's lifespan so
    that the lookback window remains admissible for every record.
    """
    samples = []
    N = graph.n_firms
    T = graph.n_snapshots
    for _ in range(n_target):
        fi = int(rng.integers(0, N))
        active = graph.active_mask[fi].numpy() > 0
        idxs = np.where(active)[0]
        if len(idxs) == 0:
            continue
        qi = int(idxs[max(len(idxs) // 2, 0)])
        default = 1 if rng.random() < default_rate else 0
        samples.append(Sample(
            firm_idx=fi,
            observation_q=qi,
            default_indicator=default,
            right_censored=1 - default,
            env=env_of_q[qi] if qi < len(env_of_q) else "E4",
            default_q_within_horizon=(1 if default else -1),
        ))
    return samples


def main(config_path: str, dataset_root: str, out_dir: str):
    logger = get_logger("verify", "logs/pipeline_verification.log")
    cfg = load_config(config_path)
    set_global_seed(cfg["seed"])

    N_TARGET = cfg["verify_run"]["n_firms"]
    N_Q = cfg["verify_run"]["n_quarters"]
    quarters_all = cfg["data"]["quarters"]
    quarters = quarters_all[:N_Q]
    env_partition = {
        "E1_early": [0, N_Q // 2],
        "E1_late":  [N_Q // 2, N_Q],
    }
    logger.info(f"verification using {N_TARGET} firms across {N_Q} quarters "
                f"and env partitions {env_partition}")

    graph = build_dynamic_graph(
        dataset_root=dataset_root,
        quarters=quarters,
        env_partition=env_partition,
        n_green_indicators=cfg["data"]["n_green_indicators"],
        epsilon=cfg["data"]["epsilon"],
        firm_subset_size=N_TARGET,
        seed=cfg["seed"],
    )
    logger.info(f"graph built: N={graph.n_firms}, T={graph.n_snapshots}, "
                f"relations={len(graph.edges)}")
    edge_summary = {r: sum(e['src'].shape[0] for e in graph.edges[r])
                    for r in graph.edges}
    logger.info(f"edges per relation (total across snapshots): {edge_summary}")

    model = PIDGAT(
        node_feature_dim=graph.node_features.shape[-1],
        env_input_dim=graph.env_inputs.shape[-1],
        env_vector_dim=cfg["model"]["env_vector_dim"],
        hidden_dim=cfg["model"]["hidden_dim"],
        n_heads=cfg["model"]["n_heads"],
        n_gnn_layers=cfg["model"]["n_gnn_layers"],
        n_relations=cfg["model"]["n_relations"],
        inv_edge_feature_dim=cfg["model"]["inv_edge_feature_dim"],
        env_edge_feature_dim=cfg["model"]["env_edge_feature_dim"],
        lookback_window=cfg["model"]["lookback_window"],
        n_snapshots=graph.n_snapshots,
        dropout=cfg["model"]["dropout"],
    )
    n_params = sum(p.numel() for p in model.parameters())
    logger.info(f"model built: {n_params:,} parameters")

    trainer = PIDGATTrainer(model, graph, cfg, device="cpu")
    rng = np.random.default_rng(cfg["seed"])
    train_samples = sample_training_records(
        graph, quarters, graph.env_of_quarter, rng, n_target=800,
    )
    logger.info(f"assembled {len(train_samples)} training records")

    losses_history = []
    for epoch in range(cfg["verify_run"]["epochs"]):
        stats = trainer.train_epoch(train_samples, verify_run=True)
        losses_history.append(stats)
        logger.info(f"epoch {epoch + 1}: surv={stats['surv']:.4f} "
                    f"inv={stats['inv']:.4f} dec={stats['dec']:.4f} "
                    f"total={stats['total']:.4f}")

    scores, labels = trainer.score(train_samples[:200], verify_run=True)
    hazard_stats = {
        "n_records": int(len(scores)),
        "min": float(scores.min()) if len(scores) else None,
        "max": float(scores.max()) if len(scores) else None,
        "mean": float(scores.mean()) if len(scores) else None,
        "median": float(np.median(scores)) if len(scores) else None,
        "has_nan": bool(np.isnan(scores).any()) if len(scores) else False,
        "in_open_unit_interval": bool(((scores > 0) & (scores < 1)).all()) if len(scores) else False,
        "positive_rate": float(labels.mean()) if len(labels) else None,
    }
    logger.info(f"hazard stats: {hazard_stats}")

    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    summary = {
        "n_firms": graph.n_firms,
        "n_snapshots": graph.n_snapshots,
        "n_parameters": n_params,
        "edges_per_relation_total_over_snapshots": edge_summary,
        "epoch_losses": losses_history,
        "hazard_distribution": hazard_stats,
    }
    with open(out / "verification_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    logger.info(f"wrote {out / 'verification_summary.json'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/config.yaml")
    parser.add_argument("--dataset-root", default="../PI-DGAT_dataset")
    parser.add_argument("--out-dir", default="results/verification")
    args = parser.parse_args()
    main(args.config, args.dataset_root, args.out_dir)
