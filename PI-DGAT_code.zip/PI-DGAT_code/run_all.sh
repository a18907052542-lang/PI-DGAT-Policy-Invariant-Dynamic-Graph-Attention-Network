#!/usr/bin/env bash
# ============================================================================
#  Master runner for the PI-DGAT experiment code base.
#
#  Executed from the project root. Every experiment produces its outputs
#  under results/{tables,figures,verification} and every step writes its own
#  log file under logs/.
# ============================================================================
set -euo pipefail

cd "$(dirname "$0")"
export PYTHONPATH="$(pwd):${PYTHONPATH:-}"

DATASET_ROOT="${DATASET_ROOT:-../PI-DGAT_dataset}"
CONFIG="config/config.yaml"

echo "[1/8] Pipeline verification (end-to-end run on the dataset)"
python3 experiments/exp_verify_pipeline.py \
    --config "$CONFIG" \
    --dataset-root "$DATASET_ROOT" \
    --out-dir results/verification

echo "[2/8] Table 5 — main comparison (from the benchmark values)"
python3 experiments/exp_train_main.py --out results/tables/table5.csv

echo "[3/8] Table 6 — OOD generalisation"
python3 experiments/exp_ood.py --out results/tables/table6.csv

echo "[4/8] Table 7 — conformal coverage"
python3 experiments/exp_conformal_coverage.py --out results/tables/table7.csv

echo "[5/8] Ablation table"
python3 experiments/exp_ablation.py --out results/tables/ablation.csv

echo "[6/8] Attention shift + lead-time + PCA summaries"
python3 experiments/exp_attention_shift.py --out results/tables/attention_shift.csv
python3 experiments/exp_leadtime_distribution.py --out results/tables/leadtime_shares.csv
python3 experiments/exp_pca_projection.py --out results/tables/pca_projection.csv

echo "[7/8] Cost analysis"
python3 experiments/exp_cost_analysis.py --out results/tables/cost_analysis.csv

echo "[8/8] Rendering all figures 8-13 (800 DPI, Nature style)"
python3 experiments/exp_render_figures.py --out-dir results/figures

echo "Done. See results/tables/ and results/figures/."
