"""Nonconformity score — cumulative default probability (Eq (18))."""
from __future__ import annotations

import numpy as np


def cumulative_default_probability(hazards: np.ndarray) -> np.ndarray:
    """hazards: [N, H] hazard rate per period, H = early warning horizon.
    Returns [N] nonconformity score ς_i = 1 - prod_{t=1..H}(1 - lambda_i,t)."""
    return 1.0 - np.prod(np.clip(1.0 - hazards, 1e-9, 1.0), axis=1)
