"""Three-way decision layer (Equation (21) and Algorithm 3).

approve if ς_i <= q_hat_alpha
review  if q_hat_alpha < ς_i <= q_hat_alpha + Delta
reject  if ς_i > q_hat_alpha + Delta

Delta is calibrated so that the review proportion on the calibration set
equals the target review capacity (the target proportion of 6.2%).
"""
from __future__ import annotations

import numpy as np


APPROVE = 0
REVIEW = 1
REJECT = 2


def calibrate_buffer_width(
    calibration_scores: np.ndarray,
    q_hat: float,
    target_review_fraction: float,
) -> float:
    """Solve Delta such that
       #(q_hat < ς_i <= q_hat + Delta) / N ~= target_review_fraction.
    """
    above = calibration_scores[calibration_scores > q_hat]
    if len(above) == 0:
        return 0.03
    n = len(calibration_scores)
    target = target_review_fraction * n
    above_sorted = np.sort(above)
    k = int(min(len(above_sorted) - 1, max(0, round(target - 1))))
    return float(above_sorted[k] - q_hat)


def apply_three_way(scores: np.ndarray, q_hat: float, delta: float) -> np.ndarray:
    """Return integer decisions in {APPROVE, REVIEW, REJECT}."""
    out = np.full_like(scores, APPROVE, dtype=np.int64)
    out[(scores > q_hat) & (scores <= q_hat + delta)] = REVIEW
    out[scores > q_hat + delta] = REJECT
    return out


def empirical_false_rejection_rate(
    scores: np.ndarray,
    labels: np.ndarray,      # 1 = default, 0 = non-default
    q_hat: float,
) -> float:
    """Fraction of non-defaulting firms whose score exceeds q_hat."""
    non_default = labels == 0
    if non_default.sum() == 0:
        return 0.0
    return float((scores[non_default] > q_hat).mean())
