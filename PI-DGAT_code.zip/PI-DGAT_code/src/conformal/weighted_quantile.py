"""Time-decay weighted quantile threshold (Equation (19)).

q_hat_alpha = smallest s such that
    sum_{i in C} w_i * I[ς_i <= s] >= (1 - alpha),
w_i = zeta^(t_c - t_i), normalised over C plus a point mass at infinity.

The point-mass-at-infinity term ensures the finite-sample form of coverage
rather than the asymptotic one, as stated in Section 4.4.
"""
from __future__ import annotations

import numpy as np


def weighted_quantile_threshold(
    scores: np.ndarray,      # [N] nonconformity scores on the calibration set
    times: np.ndarray,       # [N] snapshot indices of the calibration samples
    t_c: int,                # cutoff period of the calibration set
    alpha: float,            # tolerated false rejection rate
    zeta: float,             # decay factor in (0, 1]
) -> float:
    """Return q_hat_alpha."""
    if len(scores) == 0:
        return 0.5
    w_raw = np.power(zeta, np.clip(t_c - times, 0, None).astype(float))
    # Point mass at infinity (weight 1). Since infinity always exceeds any
    # observed score, it contributes to the tail, so the normaliser is
    # sum(w_raw) + 1.
    w_norm = w_raw / (w_raw.sum() + 1.0)
    order = np.argsort(scores)
    scores_sorted = scores[order]
    w_sorted = w_norm[order]
    cum = np.cumsum(w_sorted)
    target = 1.0 - alpha
    # First index where cum >= target
    idx = np.searchsorted(cum, target, side="left")
    if idx >= len(scores_sorted):
        return scores_sorted[-1]
    return float(scores_sorted[idx])


def standard_conformal_threshold(
    scores: np.ndarray, alpha: float,
) -> float:
    """Vanilla split-conformal quantile (uniform weights) for comparison."""
    if len(scores) == 0:
        return 0.5
    scores_sorted = np.sort(scores)
    n = len(scores_sorted)
    k = int(np.ceil((n + 1) * (1 - alpha))) - 1
    k = min(max(k, 0), n - 1)
    return float(scores_sorted[k])
