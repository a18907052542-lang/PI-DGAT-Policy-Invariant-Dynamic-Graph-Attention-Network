"""Environment encoder implementing Equations (2), (3), (4).

Equation (2)  Policy intensity  p_t = sum_k I(t >= t_k) * r_k * gamma_k^(t - t_k)
Equation (3)  Mask-weighted green exposure with credibility scalar
              g_i = (sum_j m_ij * w_j * v_ij) / (sum_j m_ij * w_j + eps)
              rho_i = sum_j m_ij * w_j
Equation (4)  Environment vector c_i,t = FFN([p_t, z_i,t, s_ind(i),t, g_i,t])
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import torch
import torch.nn as nn


@dataclass
class PolicyEvent:
    effective_index: int  # snapshot index (can be negative for pre-window events)
    relative_intensity: float
    decay_coefficient: float


def compute_policy_intensity(
    events: Sequence[PolicyEvent],
    n_snapshots: int,
) -> np.ndarray:
    """Vectorised implementation of Equation (2)."""
    intensity = np.zeros(n_snapshots, dtype=np.float64)
    for t in range(n_snapshots):
        for e in events:
            if t >= e.effective_index:
                intensity[t] += e.relative_intensity * (
                    e.decay_coefficient ** (t - e.effective_index)
                )
    return intensity


def scale_intensity(raw: np.ndarray, lo: float = 0.30, hi: float = 1.00) -> np.ndarray:
    """Linear rescale to [lo, hi] for numerical stability, as in file 12."""
    a, b = raw.min(), raw.max()
    if abs(b - a) < 1e-12:
        return np.full_like(raw, (lo + hi) / 2.0)
    return lo + (hi - lo) * (raw - a) / (b - a)


def mask_weighted_green_exposure(
    values: np.ndarray,          # [N, K] indicator values (NaN for missing)
    weights: np.ndarray,         # [K]     indicator weights (sum to 1)
    epsilon: float = 1e-6,
) -> tuple[np.ndarray, np.ndarray]:
    """Vectorised implementation of Equation (3).

    Returns
    -------
    exposure : [N] mask-weighted composite value
    credibility : [N] sum of observed mask * weight (0..1)
    """
    mask = (~np.isnan(values)).astype(np.float64)
    filled = np.where(mask > 0, values, 0.0)
    weighted_values = (filled * weights[None, :]) * mask
    weighted_mask = mask * weights[None, :]
    num = weighted_values.sum(axis=1)
    den = weighted_mask.sum(axis=1)
    exposure = num / (den + epsilon)
    credibility = den
    return exposure, credibility


class EnvironmentFFN(nn.Module):
    """Two-layer feedforward mapping for Equation (4)."""

    def __init__(self, in_dim: int = 4, hidden_dim: int = 16, out_dim: int = 8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def build_env_vector_inputs(
    policy_intensity_scaled: np.ndarray,   # [T]
    pilot_flag: np.ndarray,                # [N, T]  0/1
    industry_stringency: np.ndarray,       # [N, T]  in [0, 1]
    green_exposure: np.ndarray,            # [N, T]  in [0, 1]
) -> np.ndarray:
    """Assemble the raw 4-D environment input per (firm, quarter).

    Returns
    -------
    x : [N, T, 4] float32 array
    """
    n_firms, n_t = pilot_flag.shape
    p = np.broadcast_to(policy_intensity_scaled[None, :], (n_firms, n_t))
    return np.stack([p, pilot_flag, industry_stringency, green_exposure],
                    axis=-1).astype(np.float32)
