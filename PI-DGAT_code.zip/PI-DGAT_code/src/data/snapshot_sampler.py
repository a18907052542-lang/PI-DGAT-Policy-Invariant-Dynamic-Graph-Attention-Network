"""Two-hop subgraph sampler (Section 4.1: fanouts [25, 10]).

Given a batch of center firm indices at snapshot t, sample their neighbors
across all relations, then their neighbors again. All edges are unioned into
a single subgraph while keeping the relation index so that the model can
route each edge through the correct scoring branch.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import torch

from .graph_builder import DynamicGraph


@dataclass
class Subgraph:
    node_ids: torch.Tensor              # [S]
    edges: Dict[int, Dict[str, torch.Tensor]]  # per-relation edges within subgraph
    degrees: torch.Tensor               # [S]  total degree across all relations
    center_local_idx: torch.Tensor      # [B]  local indices of centers within node_ids


def _sample_neighbors(
    src: torch.Tensor,
    dst: torch.Tensor,
    inv: torch.Tensor,
    env: torch.Tensor,
    target_nodes: torch.Tensor,
    fanout: int,
    rng: np.random.Generator,
) -> Dict[str, torch.Tensor]:
    """For each node in target_nodes, sample up to `fanout` neighbors.

    Edges are treated as undirected for neighborhood sampling.
    """
    if src.numel() == 0:
        return {"src": torch.empty(0, dtype=torch.long),
                "dst": torch.empty(0, dtype=torch.long),
                "inv": torch.empty((0, inv.shape[1]), dtype=torch.float32),
                "env": torch.empty((0, env.shape[1]), dtype=torch.float32)}

    # Build undirected edge list as (src, dst) plus mirrored (dst, src).
    all_src = torch.cat([src, dst])
    all_dst = torch.cat([dst, src])
    all_inv = torch.cat([inv, inv], dim=0)
    all_env = torch.cat([env, env], dim=0)

    target_set = set(target_nodes.tolist())
    keep_mask = torch.tensor([int(s.item()) in target_set for s in all_src], dtype=torch.bool)
    all_src = all_src[keep_mask]; all_dst = all_dst[keep_mask]
    all_inv = all_inv[keep_mask]; all_env = all_env[keep_mask]

    # Sample by node.
    keep_indices: List[int] = []
    for node in target_nodes.tolist():
        rows = torch.where(all_src == node)[0]
        if len(rows) == 0:
            continue
        if len(rows) > fanout:
            picked = rng.choice(len(rows), size=fanout, replace=False)
            rows = rows[torch.as_tensor(picked)]
        keep_indices.extend(rows.tolist())
    if not keep_indices:
        return {"src": torch.empty(0, dtype=torch.long),
                "dst": torch.empty(0, dtype=torch.long),
                "inv": torch.empty((0, inv.shape[1]), dtype=torch.float32),
                "env": torch.empty((0, env.shape[1]), dtype=torch.float32)}
    idx = torch.as_tensor(keep_indices, dtype=torch.long)
    return {"src": all_src[idx], "dst": all_dst[idx],
            "inv": all_inv[idx], "env": all_env[idx]}


def sample_subgraph(
    graph: DynamicGraph,
    snapshot_idx: int,
    center_nodes: torch.Tensor,
    fanouts: List[int],
    rng: np.random.Generator,
) -> Subgraph:
    """Sample a bounded two-hop subgraph rooted at `center_nodes` in snapshot t."""
    n_relations = len(graph.edges)
    frontier = center_nodes.clone()
    seen: set = set(frontier.tolist())

    hop_edges: List[Dict[int, Dict[str, torch.Tensor]]] = []
    for hop, fanout in enumerate(fanouts):
        this_hop: Dict[int, Dict[str, torch.Tensor]] = {}
        new_nodes: set = set()
        for r in range(n_relations):
            snap = graph.edges[r][snapshot_idx]
            picked = _sample_neighbors(
                snap["src"], snap["dst"], snap["inv"], snap["env"],
                frontier, fanout, rng,
            )
            this_hop[r] = picked
            for n in picked["dst"].tolist():
                if n not in seen:
                    new_nodes.add(n)
        hop_edges.append(this_hop)
        seen.update(new_nodes)
        if not new_nodes:
            break
        frontier = torch.as_tensor(sorted(new_nodes), dtype=torch.long)

    node_ids = torch.as_tensor(sorted(seen), dtype=torch.long)
    global_to_local = {int(g): i for i, g in enumerate(node_ids.tolist())}

    # Union edges across hops, remap indices.
    union_edges: Dict[int, Dict[str, torch.Tensor]] = {r: {"src": [], "dst": [],
                                                            "inv": [], "env": []}
                                                       for r in range(n_relations)}
    for hop_dict in hop_edges:
        for r, d in hop_dict.items():
            if d["src"].numel() == 0:
                continue
            src_local = torch.as_tensor([global_to_local[int(s)] for s in d["src"].tolist()],
                                         dtype=torch.long)
            dst_local = torch.as_tensor([global_to_local[int(t)] for t in d["dst"].tolist()],
                                         dtype=torch.long)
            union_edges[r]["src"].append(src_local)
            union_edges[r]["dst"].append(dst_local)
            union_edges[r]["inv"].append(d["inv"])
            union_edges[r]["env"].append(d["env"])

    for r in range(n_relations):
        parts = union_edges[r]
        if parts["src"]:
            union_edges[r] = {
                "src": torch.cat(parts["src"]),
                "dst": torch.cat(parts["dst"]),
                "inv": torch.cat(parts["inv"], dim=0),
                "env": torch.cat(parts["env"], dim=0),
            }
        else:
            # Determine feature dims from graph
            snap0 = graph.edges[r][snapshot_idx]
            union_edges[r] = {
                "src": torch.empty(0, dtype=torch.long),
                "dst": torch.empty(0, dtype=torch.long),
                "inv": torch.empty((0, snap0["inv"].shape[1] if snap0["inv"].numel() else 1),
                                    dtype=torch.float32),
                "env": torch.empty((0, snap0["env"].shape[1] if snap0["env"].numel() else 1),
                                    dtype=torch.float32),
            }

    # Degree per subgraph node (sum across relations).
    S = len(node_ids)
    degrees = torch.zeros(S, dtype=torch.float32)
    for r in range(n_relations):
        d = union_edges[r]
        if d["src"].numel() > 0:
            degrees.scatter_add_(0, d["src"], torch.ones(d["src"].shape[0]))

    center_local = torch.as_tensor([global_to_local[int(c)] for c in center_nodes.tolist()],
                                    dtype=torch.long)
    return Subgraph(node_ids=node_ids, edges=union_edges,
                    degrees=degrees, center_local_idx=center_local)
