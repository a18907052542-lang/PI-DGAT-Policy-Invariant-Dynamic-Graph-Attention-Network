"""Right-censored discrete-time survival likelihood (Equation (14)).

L_surv = -1/N sum_i [ delta_i log(lambda_i,T_i)
                      + sum_{t < T_i} log(1 - lambda_i,t) ]

Here lambdas is a [B, W] hazard sequence, T is [B] terminal indices (0..W-1),
delta is [B] default indicator (1 default, 0 right-censored).
"""
from __future__ import annotations

import torch


def censored_negative_log_likelihood(
    lambdas: torch.Tensor,       # [B, W]
    T: torch.Tensor,             # [B] long
    delta: torch.Tensor,         # [B] float 0/1
) -> torch.Tensor:
    B, W = lambdas.shape
    eps = 1e-6
    # Survival: sum_{t < T_i} log(1 - lambda_t)
    arange = torch.arange(W, device=lambdas.device).unsqueeze(0)   # [1, W]
    surv_mask = (arange < T.unsqueeze(1)).float()                   # [B, W]
    log_surv = torch.log1p(-lambdas.clamp(0.0, 1 - eps)) * surv_mask
    surv_term = log_surv.sum(dim=1)                                  # [B]

    # Terminal-event hazard log
    idx = T.clamp(min=0, max=W - 1)
    haz_at_T = lambdas.gather(1, idx.unsqueeze(1)).squeeze(1).clamp(eps, 1 - eps)
    event_term = delta * torch.log(haz_at_T)                          # [B]

    # Negative log-likelihood mean
    nll = -(event_term + surv_term).mean()
    return nll
