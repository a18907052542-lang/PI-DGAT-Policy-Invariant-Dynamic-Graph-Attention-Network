"""Orthogonality constraint between the two branches (Equation (16)).

L_dec = || S_inv^T S_env ||_F^2

where S_inv and S_env are per-batch score matrices from the two branches.
The batches provided are stacked over all edges in the sampled subgraph so
that the constraint is enforced pathwise rather than per relation.
"""
from __future__ import annotations

import torch


def decorrelation_loss(S_inv: torch.Tensor, S_env: torch.Tensor) -> torch.Tensor:
    if S_inv.numel() == 0 or S_env.numel() == 0:
        return torch.tensor(0.0, device=S_inv.device)
    # Centre and unit-normalise columns so scale is not part of the loss
    def _standardise(x: torch.Tensor) -> torch.Tensor:
        x = x - x.mean(dim=0, keepdim=True)
        norm = x.norm(dim=0, keepdim=True).clamp(min=1e-6)
        return x / norm

    A = _standardise(S_inv)     # [E, H]
    B = _standardise(S_env)     # [E, H]
    C = A.T @ B                  # [H, H]
    return (C.pow(2)).sum()
