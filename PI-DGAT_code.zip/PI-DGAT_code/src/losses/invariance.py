"""Cross-environment invariance constraint (Equation (15)).

L_inv = Var_e[ L_e ] + mean_e[ || grad_{theta_inv} L_e ||^2 ]

The gradient norm is computed by differentiating each per-environment loss
w.r.t. the invariant-branch parameters and averaging the squared L2 norms.
"""
from __future__ import annotations

from typing import List

import torch


def compute_invariance_loss(
    per_env_losses: List[torch.Tensor],
    invariant_params: List[torch.nn.Parameter],
) -> torch.Tensor:
    """Return L_inv given a list of scalar per-environment loss tensors and
    the parameter iterable of the invariant branch."""
    if len(per_env_losses) < 2:
        return torch.tensor(0.0, device=per_env_losses[0].device
                            if per_env_losses else "cpu")
    stack = torch.stack(per_env_losses)
    variance = stack.var(unbiased=False)

    grad_norms: List[torch.Tensor] = []
    for L_e in per_env_losses:
        grads = torch.autograd.grad(
            L_e, invariant_params,
            create_graph=True, retain_graph=True, allow_unused=True,
        )
        sq = torch.tensor(0.0, device=L_e.device)
        for g in grads:
            if g is None:
                continue
            sq = sq + g.pow(2).sum()
        grad_norms.append(sq)
    grad_mean = torch.stack(grad_norms).mean()

    return variance + grad_mean
