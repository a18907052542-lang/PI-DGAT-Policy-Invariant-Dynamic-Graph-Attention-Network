"""Evaluation metrics — AUC, KS, average precision, early-warning lead time."""
from __future__ import annotations

from typing import Sequence

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def auc(labels: np.ndarray, scores: np.ndarray) -> float:
    if len(np.unique(labels)) < 2:
        return 0.5
    return float(roc_auc_score(labels, scores))


def ks_statistic(labels: np.ndarray, scores: np.ndarray) -> float:
    """Kolmogorov–Smirnov statistic between positive and negative score
    distributions."""
    pos = scores[labels == 1]
    neg = scores[labels == 0]
    if len(pos) == 0 or len(neg) == 0:
        return 0.0
    grid = np.unique(np.concatenate([pos, neg]))
    if len(grid) > 4000:
        grid = np.quantile(grid, np.linspace(0, 1, 4000))
    ks = 0.0
    for t in grid:
        f_pos = (pos <= t).mean()
        f_neg = (neg <= t).mean()
        ks = max(ks, abs(f_pos - f_neg))
    return float(ks)


def average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    if labels.sum() == 0:
        return 0.0
    return float(average_precision_score(labels, scores))


def early_warning_lead_time(
    default_quarters: np.ndarray,     # [K] snapshot index of actual default
    first_alarm_quarters: np.ndarray, # [K] snapshot at which score first exceeds threshold
) -> np.ndarray:
    """Compute per-event lead time as (default_q - first_alarm_q).

    Positive means the alarm came earlier than the default. Negative or
    infinite means the alarm never came before default (excluded from mean).
    """
    lead = default_quarters - first_alarm_quarters
    return lead.astype(np.float64)


def summarise_lead_time(leads: np.ndarray) -> tuple[float, float]:
    """Return mean and standard deviation of lead time over valid values."""
    valid = leads[leads >= 0]
    if len(valid) == 0:
        return 0.0, 0.0
    return float(valid.mean()), float(valid.std())


def bin_lead_time(leads: np.ndarray, edges: Sequence[float] = (0, 1, 2, 3, 4, 5)) -> np.ndarray:
    """Return counts per bin defined by `edges` (closed left, open right)."""
    counts = np.zeros(len(edges) - 1, dtype=np.int64)
    for k in range(len(edges) - 1):
        lo, hi = edges[k], edges[k + 1]
        counts[k] = int(((leads >= lo) & (leads < hi)).sum())
    return counts
