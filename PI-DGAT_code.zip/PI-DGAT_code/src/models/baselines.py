"""Baseline models for comparison (Section 4.2).

Each baseline is a self-contained implementation trained on the same node
features and tuned on the same data split as PI-DGAT. To keep the code
readable, each is written as a small module rather than a wrapper around
another library, with the exception of LightGBM which is a natural fit for
its ecosystem.
"""
from __future__ import annotations

from typing import Dict, List

import lightgbm as lgb
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------
# LightGBM: gradient boosting on flattened node features.
# ---------------------------------------------------------------------
class LightGBMBaseline:
    def __init__(self, seed: int = 20260922):
        self.model: lgb.LGBMClassifier | None = None
        self.seed = seed

    def fit(self, X: np.ndarray, y: np.ndarray):
        self.model = lgb.LGBMClassifier(
            n_estimators=400, num_leaves=63, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8, min_child_samples=40,
            random_state=self.seed, verbose=-1,
        )
        self.model.fit(X, y)
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return self.model.predict_proba(X)[:, 1]


# ---------------------------------------------------------------------
# Homogeneous single-layer graph attention.
# ---------------------------------------------------------------------
class HomogeneousGAT(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, n_heads: int = 4):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.n_heads = n_heads
        self.head_dim = hidden_dim // n_heads
        self.W = nn.Linear(in_dim, hidden_dim, bias=False)
        self.a_src = nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.1)
        self.a_dst = nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.1)
        self.classifier = nn.Linear(hidden_dim, 1)

    def encode(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        h_ = self.W(h).view(h.shape[0], self.n_heads, self.head_dim)
        src, dst = edge_index[0], edge_index[1]
        alpha_src = (h_[src] * self.a_src[None, :, :]).sum(-1)
        alpha_dst = (h_[dst] * self.a_dst[None, :, :]).sum(-1)
        e = F.leaky_relu(alpha_src + alpha_dst, 0.2)
        # softmax over dst
        N = h.shape[0]
        max_per = torch.full((N, self.n_heads), -1e9, device=h.device)
        max_per.scatter_reduce_(0, dst[:, None].expand_as(e), e,
                                 reduce="amax", include_self=True)
        e = e - max_per[dst]
        expd = torch.exp(e)
        denom = torch.zeros((N, self.n_heads), device=h.device)
        denom.index_add_(0, dst, expd)
        alpha = expd / (denom[dst] + 1e-12)
        weighted = alpha[:, :, None] * h_[src]
        agg = torch.zeros(N, self.n_heads, self.head_dim, device=h.device)
        agg.index_add_(0, dst, weighted)
        return agg.reshape(N, self.hidden_dim)

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor,
                center_idx: torch.Tensor) -> torch.Tensor:
        z = self.encode(h, edge_index)
        return torch.sigmoid(self.classifier(z[center_idx])).squeeze(-1)


# ---------------------------------------------------------------------
# Heterogeneous attention network — HAN-style relation attention.
# ---------------------------------------------------------------------
class HAN(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, n_relations: int, n_heads: int = 4):
        super().__init__()
        self.per_rel = nn.ModuleList([
            HomogeneousGAT(in_dim, hidden_dim, n_heads) for _ in range(n_relations)
        ])
        self.attn = nn.Linear(hidden_dim, 1, bias=False)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, h, edges_by_rel, center_idx):
        per_rel_z = []
        for r, gat in enumerate(self.per_rel):
            ei = edges_by_rel[r]
            if ei.shape[1] == 0:
                per_rel_z.append(gat.encode(h, torch.empty((2, 0), dtype=torch.long,
                                                              device=h.device)))
            else:
                per_rel_z.append(gat.encode(h, ei))
        stack = torch.stack(per_rel_z, dim=1)   # [N, R, hidden]
        w = F.softmax(self.attn(stack).squeeze(-1), dim=1)
        z = (stack * w[:, :, None]).sum(dim=1)
        return torch.sigmoid(self.classifier(z[center_idx])).squeeze(-1)


# ---------------------------------------------------------------------
# EvolveGCN — GCN whose parameters evolve via a small GRU per snapshot.
# ---------------------------------------------------------------------
class EvolveGCN(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int):
        super().__init__()
        self.W_init = nn.Parameter(torch.randn(in_dim, hidden_dim) * 0.1)
        self.gru = nn.GRUCell(hidden_dim, hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, h_seq: List[torch.Tensor], edge_seq: List[torch.Tensor],
                center_idx: torch.Tensor) -> torch.Tensor:
        W = self.W_init
        h_last = None
        for h, ei in zip(h_seq, edge_seq):
            # Mean-aggregation over neighbors (simplified GCN step).
            N = h.shape[0]
            h_lin = h @ W
            if ei.shape[1] == 0:
                agg = h_lin
            else:
                src, dst = ei[0], ei[1]
                deg = torch.zeros(N, device=h.device)
                deg.scatter_add_(0, dst, torch.ones_like(dst, dtype=torch.float32))
                agg = torch.zeros_like(h_lin)
                agg.index_add_(0, dst, h_lin[src])
                agg = agg / (deg[:, None] + 1.0)
            h_last = torch.relu(agg)
            # Evolve W via GRU over W's row means.
            row_mean = W.mean(dim=0)                # [hidden]
            hidden_state = self.gru(row_mean.unsqueeze(0),
                                     W.mean(dim=0, keepdim=True)).squeeze(0)
            W = (W + hidden_state[None, :]) / 2.0
        return torch.sigmoid(self.classifier(h_last[center_idx])).squeeze(-1)


# ---------------------------------------------------------------------
# DySAT — structural attention + temporal self-attention.
# ---------------------------------------------------------------------
class DySAT(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, n_heads: int = 4):
        super().__init__()
        self.structural = HomogeneousGAT(in_dim, hidden_dim, n_heads)
        self.q = nn.Linear(hidden_dim, hidden_dim)
        self.k = nn.Linear(hidden_dim, hidden_dim)
        self.v = nn.Linear(hidden_dim, hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, h_seq, edge_seq, center_idx):
        z_seq = []
        for h, ei in zip(h_seq, edge_seq):
            if ei.shape[1] == 0:
                # Fall back to identity structural encoding
                z_seq.append(self.structural.W(h))
            else:
                z_seq.append(self.structural.encode(h, ei))
        # Stack center-node representations across time
        Zc = torch.stack([z[center_idx] for z in z_seq], dim=1)   # [B, W, hidden]
        Q = self.q(Zc); K = self.k(Zc); V = self.v(Zc)
        attn = torch.softmax(Q @ K.transpose(1, 2) / (Zc.shape[-1] ** 0.5), dim=-1)
        z = (attn @ V)[:, -1, :]
        return torch.sigmoid(self.classifier(z)).squeeze(-1)


# ---------------------------------------------------------------------
# DyMGNN — multi-relational dynamic graph attention (single-channel).
# ---------------------------------------------------------------------
class DyMGNN(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int, n_relations: int, n_heads: int = 4):
        super().__init__()
        self.per_rel = nn.ModuleList([
            HomogeneousGAT(in_dim, hidden_dim, n_heads) for _ in range(n_relations)
        ])
        self.rel_fuse = nn.Linear(hidden_dim, 1, bias=False)
        self.temporal_q = nn.Linear(hidden_dim, hidden_dim)
        self.temporal_k = nn.Linear(hidden_dim, hidden_dim)
        self.temporal_v = nn.Linear(hidden_dim, hidden_dim)
        self.classifier = nn.Linear(hidden_dim, 1)

    def forward(self, h_seq, edges_by_rel_seq, center_idx):
        per_time = []
        for h, edges_by_rel in zip(h_seq, edges_by_rel_seq):
            per_rel = []
            for r, gat in enumerate(self.per_rel):
                ei = edges_by_rel[r]
                if ei.shape[1] == 0:
                    per_rel.append(gat.W(h))
                else:
                    per_rel.append(gat.encode(h, ei))
            stack = torch.stack(per_rel, dim=1)       # [N, R, hidden]
            w = F.softmax(self.rel_fuse(stack).squeeze(-1), dim=1)
            z = (stack * w[:, :, None]).sum(dim=1)
            per_time.append(z)
        Zc = torch.stack([z[center_idx] for z in per_time], dim=1)  # [B, W, hidden]
        Q = self.temporal_q(Zc); K = self.temporal_k(Zc); V = self.temporal_v(Zc)
        attn = torch.softmax(Q @ K.transpose(1, 2) / (Zc.shape[-1] ** 0.5), dim=-1)
        z = (attn @ V)[:, -1, :]
        return torch.sigmoid(self.classifier(z)).squeeze(-1)
