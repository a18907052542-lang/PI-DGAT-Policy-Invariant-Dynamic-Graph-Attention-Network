"""Dual-channel graph attention operator (Section 3.2, Algorithm 1).

Equations implemented:
  (5)  s_inv = a_r' * LeakyReLU(W_r * concat(h_i, h_j, u_inv))
  (6)  s_env = b_r' * LeakyReLU(V_r * concat(u_env, c_i, c_j))
  (7)  score = s_inv + g_ir * s_env; alpha = softmax_j(score)
       g_ir = sigmoid(w_gamma_r' * c_i)
  (8)  h_i_r = beta_i * W_s * h_i + (1 - beta_i) * sum_j alpha_ij * W_r * h_j
  (9)  beta_i = sigmoid(theta1 * log(1 + degree_i) + theta2 * rho_i + theta0)
  (10) pi_ir = softmax_r(q' * tanh(P * h_i_r));  m_i = sum_r pi_ir * h_i_r
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class SinglePassDualChannelAttention(nn.Module):
    """One layer of the multi-head dual-channel graph attention operator.

    All relations share hidden_dim but keep their own edge-feature dims.
    """

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        n_heads: int,
        n_relations: int,
        env_vector_dim: int,
        inv_edge_feature_dim: List[int],
        env_edge_feature_dim: List[int],
        dropout: float = 0.1,
    ):
        super().__init__()
        assert hidden_dim % n_heads == 0, "hidden_dim must be divisible by n_heads"
        self.in_dim = in_dim
        self.hidden_dim = hidden_dim
        self.n_heads = n_heads
        self.head_dim = hidden_dim // n_heads
        self.n_relations = n_relations
        self.env_vector_dim = env_vector_dim
        self.dropout = dropout

        # Per-relation invariant branch: W_r maps (h_i, h_j, u_inv) -> hidden
        self.W_r = nn.ModuleList([
            nn.Linear(2 * in_dim + inv_edge_feature_dim[r], hidden_dim, bias=False)
            for r in range(n_relations)
        ])
        # Per-relation environment branch: V_r maps (u_env, c_i, c_j) -> hidden
        self.V_r = nn.ModuleList([
            nn.Linear(env_edge_feature_dim[r] + 2 * env_vector_dim, hidden_dim, bias=False)
            for r in range(n_relations)
        ])
        # Attention scoring vectors (per relation, per head)
        self.a_r = nn.ParameterList([
            nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.1)
            for _ in range(n_relations)
        ])
        self.b_r = nn.ParameterList([
            nn.Parameter(torch.randn(n_heads, self.head_dim) * 0.1)
            for _ in range(n_relations)
        ])
        # Gating: g_ir = sigmoid(w_gamma_r' * c_i)
        self.w_gamma_r = nn.ParameterList([
            nn.Parameter(torch.randn(env_vector_dim) * 0.1)
            for _ in range(n_relations)
        ])

        # Per-relation neighbor value projection: W_r_val (h_j) -> hidden
        self.W_r_val = nn.ModuleList([
            nn.Linear(in_dim, hidden_dim, bias=False) for _ in range(n_relations)
        ])

        # Self-preserving residual
        self.W_s = nn.Linear(in_dim, hidden_dim, bias=False)
        self.theta0 = nn.Parameter(torch.zeros(1))
        # Paper says theta1 is trained to be negative; initialise it small negative.
        self.theta1 = nn.Parameter(torch.tensor(-0.30))
        self.theta2 = nn.Parameter(torch.tensor(0.10))

        # Relation fusion (Eq (10))
        self.P = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.q_fuse = nn.Parameter(torch.randn(hidden_dim) * 0.1)

        self.leaky = nn.LeakyReLU(0.2)
        self.dropout_layer = nn.Dropout(dropout)

    # ----------------------------------------------------------------
    #  Forward pass
    # ----------------------------------------------------------------
    def forward(
        self,
        h: torch.Tensor,             # [S, in_dim]
        c: torch.Tensor,             # [S, env_vector_dim]
        edges: Dict[int, Dict[str, torch.Tensor]],
        degrees: torch.Tensor,       # [S]
        credibility: torch.Tensor,   # [S]
        return_scores: bool = False,
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Return updated node states m of shape [S, hidden_dim].

        Also returns a dictionary with per-branch score tensors for the
        orthogonality loss (Eq (16)) and, optionally for diagnostics, the
        per-relation attention weights alpha and per-node adaptive residual
        beta.
        """
        S = h.shape[0]
        aux: Dict[str, torch.Tensor] = {}

        # Adaptive residual coefficient beta (Eq (9))
        beta = torch.sigmoid(
            self.theta1 * torch.log1p(degrees)
            + self.theta2 * credibility
            + self.theta0
        )                                # [S]
        aux["beta"] = beta

        h_r_list: List[torch.Tensor] = []
        score_inv_batches: List[torch.Tensor] = []
        score_env_batches: List[torch.Tensor] = []

        for r in range(self.n_relations):
            e = edges[r]
            n_e = e["src"].shape[0]
            self_only = self.W_s(h)                          # [S, hidden]
            if n_e == 0:
                h_r_list.append(self_only)
                continue
            src = e["src"]                                    # [E]
            dst = e["dst"]                                    # [E]
            u_inv = e["inv"]                                  # [E, F_inv_r]
            u_env = e["env"]                                  # [E, F_env_r]
            h_i = h[src]                                      # [E, in_dim]
            h_j = h[dst]                                      # [E, in_dim]
            c_i = c[src]; c_j = c[dst]                        # [E, env_dim]

            # Invariant branch (Eq (5))
            inv_input = torch.cat([h_i, h_j, u_inv], dim=1)   # [E, 2 in + F_inv]
            inv_h = self.leaky(self.W_r[r](inv_input))        # [E, hidden]
            inv_h = inv_h.view(n_e, self.n_heads, self.head_dim)
            s_inv = (inv_h * self.a_r[r][None, :, :]).sum(-1) # [E, n_heads]

            # Environment branch (Eq (6))
            env_input = torch.cat([u_env, c_i, c_j], dim=1)   # [E, F_env + 2 env_dim]
            env_h = self.leaky(self.V_r[r](env_input))
            env_h = env_h.view(n_e, self.n_heads, self.head_dim)
            s_env = (env_h * self.b_r[r][None, :, :]).sum(-1) # [E, n_heads]

            score_inv_batches.append(s_inv)
            score_env_batches.append(s_env)

            # Gating (Eq (7))
            g_ir = torch.sigmoid((c_i * self.w_gamma_r[r][None, :]).sum(-1))  # [E]
            score = s_inv + g_ir[:, None] * s_env             # [E, n_heads]

            # Softmax over j within neighbors of i, per head.
            # Trick: subtract per-i max, exp, then scatter-normalise.
            alpha = self._softmax_edges(score, src, S)         # [E, n_heads]

            # Value projection then per-head aggregation.
            v_j = self.W_r_val[r](h_j)                          # [E, hidden]
            v_j = v_j.view(n_e, self.n_heads, self.head_dim)    # [E, n_heads, head_dim]
            weighted = alpha[:, :, None] * v_j                  # [E, n_heads, head_dim]
            agg = torch.zeros(S, self.n_heads, self.head_dim, device=h.device)
            agg.index_add_(0, src, weighted)                    # [S, n_heads, head_dim]
            agg = agg.reshape(S, self.hidden_dim)               # [S, hidden]

            # Self-preserving residual (Eq (8))
            h_r = beta[:, None] * self_only + (1 - beta[:, None]) * agg
            h_r_list.append(h_r)

        # Relation fusion (Eq (10))
        h_r_stack = torch.stack(h_r_list, dim=1)               # [S, R, hidden]
        u = torch.tanh(self.P(h_r_stack))                       # [S, R, hidden]
        pi_logits = (u * self.q_fuse[None, None, :]).sum(-1)    # [S, R]
        pi = F.softmax(pi_logits, dim=1)                        # [S, R]
        m = (h_r_stack * pi[:, :, None]).sum(dim=1)             # [S, hidden]
        aux["pi"] = pi

        # Concatenate per-relation scores for orthogonality loss (Eq (16))
        if score_inv_batches:
            aux["S_inv"] = torch.cat(score_inv_batches, dim=0)  # [sum_E, n_heads]
            aux["S_env"] = torch.cat(score_env_batches, dim=0)
        else:
            aux["S_inv"] = torch.zeros((0, self.n_heads))
            aux["S_env"] = torch.zeros((0, self.n_heads))

        return self.dropout_layer(m), aux

    @staticmethod
    def _softmax_edges(scores: torch.Tensor, src: torch.Tensor, num_nodes: int) -> torch.Tensor:
        """Numerically stable softmax over incoming edges of each node."""
        # scores: [E, H]; src: [E]
        # per-node max
        max_per_node = torch.full((num_nodes, scores.shape[1]), -1e9,
                                    device=scores.device, dtype=scores.dtype)
        max_per_node.scatter_reduce_(0, src[:, None].expand_as(scores),
                                     scores, reduce="amax", include_self=True)
        scores_shift = scores - max_per_node[src]
        expd = torch.exp(scores_shift)
        denom = torch.zeros((num_nodes, scores.shape[1]),
                             device=scores.device, dtype=scores.dtype)
        denom.index_add_(0, src, expd)
        return expd / (denom[src] + 1e-12)


class DualChannelStack(nn.Module):
    """Stack of two dual-channel graph attention layers (Section 4.1)."""

    def __init__(
        self,
        in_dim: int,
        hidden_dim: int,
        n_heads: int,
        n_layers: int,
        n_relations: int,
        env_vector_dim: int,
        inv_edge_feature_dim: List[int],
        env_edge_feature_dim: List[int],
        dropout: float = 0.1,
    ):
        super().__init__()
        self.input_proj = nn.Linear(in_dim, hidden_dim)
        self.layers = nn.ModuleList()
        for _ in range(n_layers):
            self.layers.append(SinglePassDualChannelAttention(
                in_dim=hidden_dim,
                hidden_dim=hidden_dim,
                n_heads=n_heads,
                n_relations=n_relations,
                env_vector_dim=env_vector_dim,
                inv_edge_feature_dim=inv_edge_feature_dim,
                env_edge_feature_dim=env_edge_feature_dim,
                dropout=dropout,
            ))
        self.layer_norms = nn.ModuleList([nn.LayerNorm(hidden_dim) for _ in range(n_layers)])
        self.n_layers = n_layers

    def forward(
        self,
        h_in: torch.Tensor,
        c: torch.Tensor,
        edges,
        degrees,
        credibility,
    ):
        h = self.input_proj(h_in)
        all_S_inv: List[torch.Tensor] = []
        all_S_env: List[torch.Tensor] = []
        pi_last = None
        beta_last = None
        for i, layer in enumerate(self.layers):
            m, aux = layer(h, c, edges, degrees, credibility)
            h = self.layer_norms[i](m + h)
            all_S_inv.append(aux["S_inv"])
            all_S_env.append(aux["S_env"])
            pi_last = aux.get("pi")
            beta_last = aux.get("beta")
        return h, {"S_inv": all_S_inv[-1], "S_env": all_S_env[-1],
                   "pi_last": pi_last, "beta_last": beta_last}
