"""Environment intervention (Equation (11)).

At training time, the environment vectors of the current sample are replaced
by vectors sampled from another policy environment e'. Only the environment
branch input changes; the invariant score s_inv is untouched.
"""
from __future__ import annotations

from typing import Dict, List

import torch


def sample_env_vectors(
    env_bank: Dict[str, torch.Tensor],
    target_env: str,
    n_samples: int,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    """Draw n_samples environment vectors uniformly from env `target_env`."""
    pool = env_bank[target_env]                # [P, env_dim]
    if pool.shape[0] == 0:
        raise ValueError(f"env_bank['{target_env}'] is empty")
    idx = torch.randint(0, pool.shape[0], (n_samples,), generator=generator)
    return pool[idx]


def build_env_bank(
    env_vectors: torch.Tensor,     # [N, T, env_dim]
    env_of_quarter: List[str],
    active_mask: torch.Tensor,     # [N, T]
) -> Dict[str, torch.Tensor]:
    """Group all valid (firm, quarter) environment vectors by their env label."""
    bank: Dict[str, List[torch.Tensor]] = {}
    N, T, _ = env_vectors.shape
    for t in range(T):
        e = env_of_quarter[t]
        mask_t = active_mask[:, t] > 0
        if mask_t.sum() == 0:
            continue
        v = env_vectors[mask_t, t, :]
        bank.setdefault(e, []).append(v)
    return {k: torch.cat(v, dim=0) for k, v in bank.items()}
