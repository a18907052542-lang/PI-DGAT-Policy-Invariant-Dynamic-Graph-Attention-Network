"""Discrete-time hazard rate head (Equation (13)).

lambda_i,t = sigmoid(w_lam' * z_i,t + b_t)

The per-period baseline b_t absorbs common macro fluctuation. We store one
baseline per snapshot index across the observation window (T = 28).
"""
from __future__ import annotations

import torch
import torch.nn as nn


class HazardHead(nn.Module):
    def __init__(self, hidden_dim: int, n_snapshots: int):
        super().__init__()
        self.w_lam = nn.Linear(hidden_dim, 1, bias=False)
        # Baseline per snapshot period
        self.b_t = nn.Parameter(torch.zeros(n_snapshots))

    def forward(self, z: torch.Tensor, snapshot_idx: torch.Tensor) -> torch.Tensor:
        """z: [B, hidden]. snapshot_idx: [B] with the period index of each row.

        Returns hazard rates in (0, 1) of shape [B].
        """
        logits = self.w_lam(z).squeeze(-1) + self.b_t[snapshot_idx]
        return torch.sigmoid(logits)
