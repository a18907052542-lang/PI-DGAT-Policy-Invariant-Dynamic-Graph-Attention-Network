"""Full PI-DGAT model (Section 3, Algorithms 1-3)."""
from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn

from ..data.env_encoder import EnvironmentFFN
from .dual_channel_gat import DualChannelStack
from .hazard_head import HazardHead
from .temporal_head import TimeDecayAttention


class PIDGAT(nn.Module):
    """PI-DGAT: policy-invariant dynamic graph attention network."""

    def __init__(
        self,
        node_feature_dim: int,
        env_input_dim: int,
        env_vector_dim: int,
        hidden_dim: int,
        n_heads: int,
        n_gnn_layers: int,
        n_relations: int,
        inv_edge_feature_dim: List[int],
        env_edge_feature_dim: List[int],
        lookback_window: int,
        n_snapshots: int,
        dropout: float = 0.1,
        disable_env_channel: bool = False,
        disable_self_residual: bool = False,
    ):
        super().__init__()
        self.env_ffn = EnvironmentFFN(in_dim=env_input_dim, hidden_dim=16,
                                       out_dim=env_vector_dim)
        self.stack = DualChannelStack(
            in_dim=node_feature_dim,
            hidden_dim=hidden_dim,
            n_heads=n_heads,
            n_layers=n_gnn_layers,
            n_relations=n_relations,
            env_vector_dim=env_vector_dim,
            inv_edge_feature_dim=inv_edge_feature_dim,
            env_edge_feature_dim=env_edge_feature_dim,
            dropout=dropout,
        )
        self.temporal = TimeDecayAttention(hidden_dim, lookback_window)
        self.head = HazardHead(hidden_dim, n_snapshots)

        # Ablation flags
        self.disable_env_channel = disable_env_channel
        self.disable_self_residual = disable_self_residual
        if disable_self_residual:
            # Force beta -> 0 by setting theta1 to a large positive value.
            for layer in self.stack.layers:
                nn.init.constant_(layer.theta1, 0.0)
                nn.init.constant_(layer.theta2, 0.0)
                nn.init.constant_(layer.theta0, -8.0)   # sigmoid(-8) ~ 0

    # ---------------------------------------------------------------
    #  Encode a single (subgraph, snapshot) pair
    # ---------------------------------------------------------------
    def encode_snapshot(
        self,
        h_in: torch.Tensor,           # [S, node_feature_dim]
        env_raw: torch.Tensor,        # [S, env_input_dim]
        edges: Dict[int, Dict[str, torch.Tensor]],
        degrees: torch.Tensor,
        credibility: torch.Tensor,
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        c = self.env_ffn(env_raw)                # [S, env_vector_dim]
        if self.disable_env_channel:
            c = torch.zeros_like(c)
        m, aux = self.stack(h_in, c, edges, degrees, credibility)
        aux["c"] = c
        return m, aux

    # ---------------------------------------------------------------
    #  Forward the full temporal pipeline for a batch of centers.
    # ---------------------------------------------------------------
    def forward(
        self,
        seq_h: Sequence[torch.Tensor],       # W tensors [S_tau, node_feature_dim]
        seq_env: Sequence[torch.Tensor],     # W tensors [S_tau, env_input_dim]
        seq_edges: Sequence[Dict[int, Dict[str, torch.Tensor]]],  # W dicts
        seq_degrees: Sequence[torch.Tensor], # W tensors [S_tau]
        seq_credibility: Sequence[torch.Tensor],
        seq_center_local: Sequence[torch.Tensor],  # W tensors [B] local idx per snapshot
        snapshot_idx: torch.Tensor,           # [B] snapshot index t (most recent)
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Encode each snapshot, gather center-node representations, then
        time-decay attention and hazard head."""
        m_list = []
        aux_last = {"S_inv": torch.zeros((0, 1)), "S_env": torch.zeros((0, 1))}
        for tau in range(len(seq_h)):
            m_tau, aux_tau = self.encode_snapshot(
                seq_h[tau], seq_env[tau], seq_edges[tau],
                seq_degrees[tau], seq_credibility[tau],
            )
            m_center = m_tau[seq_center_local[tau]]        # [B, hidden]
            m_list.append(m_center)
            aux_last = aux_tau                              # keep the last snapshot's aux
        m_seq = torch.stack(m_list, dim=1)                  # [B, W, hidden]
        z = self.temporal(m_seq)                            # [B, hidden]
        haz = self.head(z, snapshot_idx)                    # [B]
        aux_last["z"] = z
        aux_last["m_last_center"] = m_list[-1]
        return haz, aux_last

    # ---------------------------------------------------------------
    #  Cumulative default probability over H periods (Eq (18))
    # ---------------------------------------------------------------
    @staticmethod
    def cumulative_default_probability(hazard_seq: torch.Tensor) -> torch.Tensor:
        """hazard_seq: [B, H] hazard rates for the next H periods.
        Returns [B] nonconformity score ς_i = 1 - prod(1 - λ_t)."""
        return 1.0 - torch.prod(1.0 - hazard_seq, dim=1)
