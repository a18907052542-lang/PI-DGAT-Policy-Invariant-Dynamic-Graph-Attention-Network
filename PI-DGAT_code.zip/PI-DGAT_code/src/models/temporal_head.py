"""Time-decay attention aggregator (Equation (12)).

z_i = sum_{tau=t-w+1}^{t} w_tau * m_i,tau,
w_tau = softmax_tau( q_t' * tanh(P_t * m_i,tau) - eta * (t - tau) )
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class TimeDecayAttention(nn.Module):
    def __init__(self, hidden_dim: int, lookback_window: int):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.w = lookback_window
        self.P_t = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.q_t = nn.Parameter(torch.randn(hidden_dim) * 0.1)
        # eta trained positive → distant snapshots receive smaller weight.
        # We parameterise raw and take softplus so eta > 0 always.
        self._raw_eta = nn.Parameter(torch.tensor(0.5))

    @property
    def eta(self) -> torch.Tensor:
        return F.softplus(self._raw_eta)

    def forward(self, m_seq: torch.Tensor) -> torch.Tensor:
        """m_seq: [B, W, hidden] — most-recent snapshot is m_seq[:, -1, :].

        Returns z: [B, hidden].
        """
        B, W, H = m_seq.shape
        # Content attention
        u = torch.tanh(self.P_t(m_seq))                    # [B, W, H]
        s = (u * self.q_t[None, None, :]).sum(-1)          # [B, W]
        # Time-decay penalty
        distances = torch.arange(W - 1, -1, -1, device=m_seq.device,
                                  dtype=m_seq.dtype)        # [W]
        penalty = self.eta * distances                      # [W]
        logits = s - penalty[None, :]                       # [B, W]
        w = F.softmax(logits, dim=1)                        # [B, W]
        z = (w[:, :, None] * m_seq).sum(dim=1)              # [B, H]
        return z
