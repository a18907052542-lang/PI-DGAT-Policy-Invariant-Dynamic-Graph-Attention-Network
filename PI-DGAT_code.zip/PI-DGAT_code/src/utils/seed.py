"""Reproducibility helpers."""
from __future__ import annotations

import os
import random
from pathlib import Path

import numpy as np
import torch
import yaml


def set_global_seed(seed: int) -> None:
    """Set every random-number source that PI-DGAT uses."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_config(path: str | Path) -> dict:
    """Load the YAML configuration file into a plain dict."""
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def project_root() -> Path:
    """Return the absolute path of the project root."""
    return Path(__file__).resolve().parents[2]
